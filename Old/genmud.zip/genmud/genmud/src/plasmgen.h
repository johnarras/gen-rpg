

#define PLASMGEN_COLOR_MAX 9
#define PLASMGEN_UNDERGROUND_COLOR 8
/* This lets you export an area map to a plasm file. */

void plasmgen_export (THING *area);
void add_plasm_bfs (THING *, int, int, int);
