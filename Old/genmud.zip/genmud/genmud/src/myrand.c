#include<stdlib.h>


void
my_srand (int val)
{
  srandom(val);
}
